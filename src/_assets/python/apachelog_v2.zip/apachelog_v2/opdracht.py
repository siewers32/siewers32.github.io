# ===========  Configuratie ========== #
# In de apache module staan alle functies om de logfiles te parsen en over te zetten naar de mysql-database
# Installeer de benodigde modules
# Creëer een database met een mysql-client
# Maak de tabellen aan met behulp van het bestand 'apachelog.sql'
# Configureer de gegevens voor de database connectie in apache.py

from logmodules import apache
con = apache.conn()

# pad naar het log-bestand
logfile = "small_apache.log"

# ===========  Opdracht 1 ========== #
# Maak hier het menu met opties voor de gebruiker

try:
    keuze = -1

    # ===========  Opdracht 2 ========== #
    # Zorg ervoor dat de keuze van de gebruiker in de variabele 'keuze' wordt opgeslagen
    # Een keuze mag alleen een getal zijn tussen 0 en het aantal mogelijke opties.

    # Database tabellen worden leeggemaakt
    if keuze == 0:
        apache.cleardb(con)

    # Het logfile wordt gelezen en in de database gezet
    if keuze == 1:
        parser = apache.parser()
        apache.savetodb(con, apache.parseLog(parser, logfile))

    # ===========  Opdracht 3 ========== #
    # Maak de query om het aantal post-requests mee op te vragen
    if keuze == 2:
        query = "";
        apache.select_query(con, query)

    # ===========  Opdracht 4 ========== #
    # Maak de query om het aantal get-requests mee op te vragen
    if keuze == 3:
        query = ""
        apache.select_query(con, query)

    # ===========  Opdracht 5 ========== #
    # Maak de query om de 10 meest opgevraagde pagina's weer te geven
    if keuze == 4:
        query = ""
        apache.select_query(con, query)
    # ===========  Opdracht 6 ========== #
    # Maak de query om de 10 traagste (= grootste) pagina's op te vragen
    if keuze == 5:
        query = ""
        apache.select_query(con, query)
    # ===========  Opdracht 7 ========== #
    # Maak de query om de 10 meest gebruikte browsers op te vragen
    if keuze == 6:
        query = "select useragent, count(useragent) as aantal from apache_log group by useragent order by aantal desc limit 0,10"
        apache.select_query(con, query)

    # ===========  Opdracht 7 ========== #
    # Maak de query om aanvragen weer te geven die een andere response-code teruggeven dan 200 of 201
    if keuze == 7:
        query = ""
        apache.select_query(con, query)

except ValueError as e:
    print("Voer een nummer in tussen 1 en 7")
except:
    print("Voer een nummer in tussen 1 en 7")




