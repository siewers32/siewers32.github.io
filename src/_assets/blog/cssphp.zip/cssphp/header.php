<?php
    print_r($_GET);
    $home = "not_active";
    $contact = "not_active";
    if(isset($_GET['p'])) {
        echo "er is op een link geklikt";
        if($_GET['p'] == "contact") {
            $contact = "active";
        }
        if($_GET['p'] == "home") {
            $home = "active";
        }       
    } else {
        $home = "active";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website</title>
    <link rel="stylesheet" type="text/css" href="css/mijnstijl.css">
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="logo">
            </div>
            <nav>
                <a class="<?php echo $home ?>" href="index.php?p=home">Home</a>
                <a class="<?php echo $contact ?>"href="contact.php?p=contact">Contact</a>
                <a href="#">Linkje 1</a>
            </nav>
        </header>
        <main>