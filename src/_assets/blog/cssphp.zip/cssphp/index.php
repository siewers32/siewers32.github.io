<?php
    include('header.php');
?>
<h1>Dit is de homepage</h1>
<?php
    include('footer.php');
?>