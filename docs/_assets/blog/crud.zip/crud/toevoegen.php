<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Toevoegen</h1>
    <form action="db.php" method="post">
    Landcode: <input type="text" name="lc"><br>
    Werelddeelcode: <input type="text" name="wc"><br>
    Landnaam: <input type="text" name="ln"><br>
    <input type="submit" name="knop">
    </form>
    <a href="db.php">Resultaat bekijken</a>
</body>
</html>