

<?php
 $servername = "localhost";
 $username = "wim";
 $password = "wim";
 $db = "wereld";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


 // Toevoegen
if(isset($_POST['knop'])) {
    echo "Ik ga iets toevoegen";
    // prepare and bind
    $sql = "INSERT INTO land (werelddeelcode, landcode, landnaam) VALUES (?,?,?)";
    // prepare and bind
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $_POST["wc"],$_POST["lc"],$_POST["ln"]);
    $stmt->execute();
    
}


 $sql = "SELECT * FROM land";
 $result = $result = $conn->query($sql);

 if ($result->num_rows > 0)  {
    // output data of each row
    $html = "<table>";
    $html .= "<tr><th>landcode</th><th>werelddeelcode</th><th>landnaam</th></tr>";
    while($row = $result->fetch_assoc())  {
      $html .= "<tr><td>".$row["landcode"]."</td><td>" . $row["werelddeelcode"]. "</td><td>" . $row["landnaam"]. "</td></tr>";
    }
    $html .= "</table>";
  } else {
    echo "0 results";
  }
  

 ?> 

 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <body>
    <?php echo $html; ?>
    <a href="toevoegen.php">Voeg nog een land toe</a>
 </body>
 </html>