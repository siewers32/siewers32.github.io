const saveBtn = document.getElementById('save-btn');
const resetBtn = document.getElementById('reset-btn');
const usernameInput = document.getElementById('username-input');
const themeSelect = document.getElementById('theme-select');
const welcomeMessage = document.getElementById('welcome-message');

// Functie om de instellingen toe te passen op de pagina
function applySettings(name, theme) {
    if (name) welcomeMessage.innerText = `Welkom, ${name}`;
    if (theme) {
        document.body.className = ''; // Verwijder oude classes
        document.body.classList.add(theme);
        themeSelect.value = theme;
    }
}

// 1. TODO: Maak een functie 'loadSettings' die kijkt in localStorage
function loadSettings() {
    // Gebruik localStorage.getItem(...)
    // Vergeet applySettings(naam, thema) niet aan te roepen!
}

// 2. TODO: Maak een functie 'saveSettings'
saveBtn.addEventListener('click', () => {
    const name = usernameInput.value;
    const theme = themeSelect.value;
    
    // Gebruik localStorage.setItem(...)
    applySettings(name, theme);
    alert('Instellingen opgeslagen!');
});

// 3. TODO: Maak de reset-knop werkend
resetBtn.addEventListener('click', () => {
    // Gebruik localStorage.clear() en refresh de pagina
});

// Start de app
loadSettings();